/*! lifestyle-2.js | Huro | Css ninja 2020-2021 */

"use strict";

$(document).ready(function () {});
